export const pepper: string = process.env.BCRYPT_PASSWORD as string;
export const saltRounds: string = process.env.SALT_ROUNDS as string;
